import * as Yup from "yup"


const passwordRegExp =
  /^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-_]).{6,}$/;

export const LoginSchema =  Yup.object().shape({
    email: Yup.string()
    .email("Invalid email address.")
    .required("This field is required.")
    .label("Email address."),
    password: Yup.string()
    .required("This field is required.")
    .min(6, "Password must be al least 6 characters.")
    .matches(passwordRegExp, "Password must contain A-Z, a-z, 0-9")
    .label("Password.")
})
